library(dplyr)
library(ggplot2)
library(gridExtra)
library(kableExtra)

# Vectorized Monte Carlo option pricing function
# Vectorized Monte Carlo option pricing function
monte_carlo_option_pricing <- function(S, X, T_days, sigma, r = 0.051,
                                       option_type, n_sim = 50000) {
  T <- T_days / 252  # Convert days to years
  Z <- rnorm(n_sim)  # Generate n_sim random numbers at once
  S_T <- S * exp((r - 0.5 * sigma^2) * T + sigma * sqrt(T) * Z)
  
  # Vectorized handling of option type using ifelse
  payoff <- ifelse(option_type == "c", pmax(S_T - X, 0), pmax(X - S_T, 0))
  
  # Calculate discounted mean payoff
  price <- mean(payoff) * exp(-r * T)
  return(price)
}


# Apply the function for different volatilities and store the results in the data
for (i in seq_along(volatilities)) {
  col_name <- paste0("mc_price_sigma", i)
  data[[col_name]] <- mapply(monte_carlo_option_pricing,
                             S = data$underlying_trade_price,
                             X = data$strike,
                             T_days = data$n_giorni,
                             sigma = volatilities[[i]],
                             MoreArgs = list(r = 0.051, n_sim = 50000,
                                             option_type = data$option_type))
}

# RMSE and R-squared calculation helper function
calculate_rmse_r2 <- function(dati, col_name, price_col) {
  rmse_val <- sqrt(mean((dati[[price_col]] - dati[[col_name]])^2))
  rss <- sum((dati[[col_name]] - dati[[price_col]])^2)
  tss <- sum((dati[[price_col]] - mean(dati[[price_col]]))^2)
  r_squared <- 1 - (rss / tss)
  return(list(rmse = rmse_val, r_squared = r_squared))
}

# Prepare RMSE and R-squared for Call and Put
rmse_r2_table <- function(dati, type) {
  result_list <- list()
  for (i in seq_along(volatilities)) {
    col_name <- paste0("mc_price_sigma", i)
    rmse_trade <- calculate_rmse_r2(dati, col_name, "trade_price")
    rmse_theo <- calculate_rmse_r2(dati, col_name, "theo_price")
    
    result_list[[i]] <- data.frame(
      Tipo = type,
      Sigma = paste0("Sigma ", i),
      RMSE_Trade_Price = rmse_trade$rmse,
      RMSE_Theo_Price = rmse_theo$rmse,
      R2_Trade = rmse_trade$r_squared,
      R2_Theo = rmse_theo$r_squared
    )
  }
  return(do.call(rbind, result_list))
}

# Combine results for Call and Put
rmse_table_call <- rmse_r2_table(dati_call, "Call")
rmse_table_put <- rmse_r2_table(dati_put, "Put")

# Final RMSE and R-squared Table
rmse_table_mc <- rbind(rmse_table_call, rmse_table_put)

# Display RMSE and R-squared results
kable(rmse_table_mc, caption = "RMSE e R^2 per diversi valori di Sigma con Monte Carlo per Call e Put",
      col.names = c("Tipologia", "Sigma", "RMSE Prezzi di Scambio", "RMSE Prezzi Teorici", "R^2 Trade", "R^2 Theo")) %>%
  kable_styling(full_width = FALSE, position = "center")

# Plotting function
plot_mc_vs_trade <- function(dati, col_name, sigma_label, type, color) {
  ggplot(dati, aes_string(x = "trade_price", y = col_name)) +
    geom_point(color = color) +
    geom_abline(intercept = 0, slope = 1, color = "green",
                linetype = "dashed") +
    labs(x = "Prezzo di Scambio Osservato", y = paste("Prezzo MC", sigma_label)) +
    ggtitle(paste(type, " - Monte Carlo", sigma_label)) +
    theme_minimal() +
    theme(axis.text.x = element_text(size = 16),
          axis.text.y = element_text(size = 16),
          axis.title.x = element_text(size = 18),
          axis.title.y = element_text(size = 18))
}

# Create plots for Call and Put for all sigmas
plot_call_mc <- grid.arrange(
  plot_mc_vs_trade(dati_call, "mc_price_sigma1", "Sigma 1", "Call", "blue"),
  plot_mc_vs_trade(dati_call, "mc_price_sigma2", "Sigma 2", "Call", "blue"),
  plot_mc_vs_trade(dati_call, "mc_price_sigma3", "Sigma 3", "Call", "blue"),
  nrow = 1
)

plot_put_mc <- grid.arrange(
  plot_mc_vs_trade(dati_put, "mc_price_sigma1", "Sigma 1", "Put", "red"),
  plot_mc_vs_trade(dati_put, "mc_price_sigma2", "Sigma 2", "Put", "red"),
  plot_mc_vs_trade(dati_put, "mc_price_sigma3", "Sigma 3", "Put", "red"),
  nrow = 1
)

# Density Plot function
plot_density <- function(dati, type, color) {
  ggplot() +
    geom_density(data = dati, aes(x = trade_price, color = "Osservati"), size = 1) +
    geom_density(data = dati, aes(x = mc_price_sigma1, color = "Previsti (Sigma 1)"), linetype = "dashed", size = 1) +
    geom_density(data = dati, aes(x = mc_price_sigma2, color = "Previsti (Sigma 2)"), linetype = "dotted", size = 1) +
    geom_density(data = dati, aes(x = mc_price_sigma3, color = "Previsti (Sigma 3)"), linetype = "longdash", size = 1) +
    labs(x = "Prezzo", y = "Densità", color = "Legenda") +
    ggtitle(paste("Distribuzione Prezzi", type)) +
    theme_minimal() +
    theme(axis.text.x = element_text(size = 16),
          axis.text.y = element_text(size = 16),
          axis.title.x = element_text(size = 18),
          axis.title.y = element_text(size = 18))
}

# Density plots for Call and Put
density_plot_call <- plot_density(dati_call, "Call", "blue")
density_plot_put <- plot_density(dati_put, "Put", "red")

print(density_plot_call)
print(density_plot_put)

# Save Plots
ggsave("confronto_call_mc.png", plot = plot_call_mc, width = 14, height = 5)
ggsave("confronto_put_mc.png", plot = plot_put_mc, width = 14, height = 5)
ggsave("confronto_call_mc_density.png", plot = density_plot_call, width = 14, height = 5)
ggsave("confronto_put_mc_density.png", plot = density_plot_put, width = 14, height = 5)
