library(xgboost)
library(Metrics)
library(doParallel)
library(dplyr)
library(caret)
library(ggplot2)
library(data.table)


cl <- makeCluster(detectCores() - 2)  # Reduce the number of cores used
registerDoParallel(cl)
# Load data
load("DATASET_DEFINITIVO.RData")

# Data Manipulation
preprocess_data <- function(final_train_data) {
  final_train_data %>%
    mutate(
      option_type = as.integer(option_type == "p"),
      delivery = as.integer(delivery == "C"),
      n_giorni = as.integer(n_giorni)
    ) %>%
    select(-c(
      "underlying_symbol", "expiration", "exercise", "root", 
      "trade_condition_id",
      "trade_datetime", "settlement", "multiplier", 
      "exchange_sequence_number",
      "exchange_id", "volatilita_annuale_1", "volatilita_annuale_3"
    ))
}

# Split data by option type
split_by_option_type <- function(X) {
  list(
    call = X %>% filter(option_type == 0),
    put = X %>% filter(option_type == 1)
  )
}

# Prepare datasets for training
prepare_datasets <- function(data_split, target_col) {
  list(
    call = list(
      X = data_split$call %>% select(-all_of(target_col)),
      y = data_split$call[[target_col]]
    ),
    put = list(
      X = data_split$put %>% select(-all_of(target_col)),
      y = data_split$put[[target_col]]
    )
  )
}

# Define optional and no optional features
features <- list(
  optional = c('delivery', 'open_interest', 'underlying_bid', "underlying_ask", 
               'trade_delta', 'trade_gamma', 'trade_vega', 'trade_theta', 
               "trade_rho", "theo_iv", "trade_size", "trade_iv"),
  non_optional = c("strike", "n_giorni", "volatilita_annuale_2")
)

# Generate feature combinations (100 samples)
generate_feature_combinations <- function(features, n_samples = 100) {
  set.seed(42)
  combinations <- lapply(0:length(features$optional), function(n) {
    combn(features$optional, n, simplify = FALSE)
  })
  all_combinations <- unlist(combinations, recursive = FALSE)
  feature_subsets <- lapply(all_combinations,
                            function(x) c(features$non_optional, x))
  
  # Sample if needed
  if (length(feature_subsets) > n_samples) {
    feature_subsets[sample(length(feature_subsets), n_samples)]
  } else {
    feature_subsets
  }
}

# Optimized training function with early stopping
train_model <- function(X, y, feature_subset) {
  set.seed(40)
  
  # Create train/test split indices once
  n_samples <- nrow(X)
  train_idx <- createDataPartition(y, p = .8, list = FALSE, times = 1)
  test_idx <- setdiff(1:n_samples, train_idx)
  
  # Prepare matrices directly with selected features
  train_matrix <- as.matrix(X[train_idx, feature_subset])
  test_matrix <- as.matrix(X[test_idx, feature_subset])
  
  dtrain <- xgb.DMatrix(data = train_matrix, label = y[train_idx])
  dtest <- xgb.DMatrix(data = test_matrix, label = y[test_idx])
  
  # Fixed hyperparameters
  params <- list(
    objective = "reg:squarederror",
    eval_metric = "rmse",
    max_depth = 5,
    eta = 0.2,
    gamma = 2,
    colsample_bytree = 1,
    min_child_weight = 1,
    subsample = 0.8
  )
  
  # Cross-validation with early stopping
  cv_results <- xgb.cv(
    params = params,
    data = dtrain,
    nrounds = 200,
    nfold = 5,
    early_stopping_rounds = 10,
    maximize = FALSE,
    metrics = "rmse",
    verbose = 0
  )
  
  # Train final model
  model <- xgb.train(
    params = params,
    data = dtrain,
    nrounds = cv_results$best_iteration,
    verbose = 0
  )
  
  # Evaluate
  predictions <- predict(model, dtest)
  rmse <- sqrt(mean((predictions - y[test_idx])^2))
  r2 <- 1 - sum((predictions - y[test_idx])^2) / sum((y[test_idx] - mean(y[test_idx]))^2)
  
  list(
    model = model,
    rmse = rmse,
    r2 = r2,
    predictions = predictions,
    test_targets = y[test_idx],
    features = feature_subset
  )
}

# Main execution function
run_model_selection <- function(final_train_data) {
  # Preprocess data
  X <- preprocess_data(final_train_data)
  data_split <- split_by_option_type(X)
  
  # Prepare datasets
  scambio_datasets <- prepare_datasets(data_split, "underlying_trade_price")
  theo_datasets <- prepare_datasets(data_split, "theo_price")
  
  # Generate feature combinations
  feature_subsets <- generate_feature_combinations(features)
  
  # Initialize vectors to store results
  n_subsets <- length(feature_subsets)
  results_tracking <- list(
    RMSE_Call_Scambio = numeric(n_subsets),
    RMSE_Put_Scambio = numeric(n_subsets),
    RMSE_Call_Theo = numeric(n_subsets),
    RMSE_Put_Theo = numeric(n_subsets),
    R2_Call_Scambio = numeric(n_subsets),
    R2_Put_Scambio = numeric(n_subsets),
    R2_Call_Theo = numeric(n_subsets),
    R2_Put_Theo = numeric(n_subsets)
  )
  
  # Initialize best results
  best_results <- list(
    call_scambio = list(rmse = Inf, model = NULL, features = NULL),
    put_scambio = list(rmse = Inf, model = NULL, features = NULL),
    call_theo = list(rmse = Inf, model = NULL, features = NULL),
    put_theo = list(rmse = Inf, model = NULL, features = NULL)
  )
  
  # Train and evaluate models
  for (i in seq_along(feature_subsets)) {
    feature_subset <- feature_subsets[[i]]
    cat(sprintf("\rEvaluating feature subset %d/%d", i, n_subsets))
    
    # Train models and store results
    current_results <- list(
      call_scambio = train_model(scambio_datasets$call$X, scambio_datasets$call$y, feature_subset),
      put_scambio = train_model(scambio_datasets$put$X, scambio_datasets$put$y, feature_subset),
      call_theo = train_model(theo_datasets$call$X, theo_datasets$call$y, feature_subset),
      put_theo = train_model(theo_datasets$put$X, theo_datasets$put$y, feature_subset)
    )
    
    # Store results in tracking vectors
    results_tracking$RMSE_Call_Scambio[i] <- current_results$call_scambio$rmse
    results_tracking$RMSE_Put_Scambio[i] <- current_results$put_scambio$rmse
    results_tracking$RMSE_Call_Theo[i] <- current_results$call_theo$rmse
    results_tracking$RMSE_Put_Theo[i] <- current_results$put_theo$rmse
    
    results_tracking$R2_Call_Scambio[i] <- current_results$call_scambio$r2
    results_tracking$R2_Put_Scambio[i] <- current_results$put_scambio$r2
    results_tracking$R2_Call_Theo[i] <- current_results$call_theo$r2
    results_tracking$R2_Put_Theo[i] <- current_results$put_theo$r2
    
    # Update best results if better
    for (model_type in names(best_results)) {
      if (current_results[[model_type]]$rmse < best_results[[model_type]]$rmse) {
        best_results[[model_type]] <- current_results[[model_type]]
      }
    }
  }
  cat("\nModel selection completed!\n")
  
  # Create comprehensive results dataframe
  results_df <- data.frame(
    Feature_Set = 1:n_subsets,
    Features = sapply(feature_subsets, paste, collapse = ", "),
    RMSE_Call_Scambio = results_tracking$RMSE_Call_Scambio,
    RMSE_Put_Scambio = results_tracking$RMSE_Put_Scambio,
    RMSE_Call_Theo = results_tracking$RMSE_Call_Theo,
    RMSE_Put_Theo = results_tracking$RMSE_Put_Theo,
    R2_Call_Scambio = results_tracking$R2_Call_Scambio,
    R2_Put_Scambio = results_tracking$R2_Put_Scambio,
    R2_Call_Theo = results_tracking$R2_Call_Theo,
    R2_Put_Theo = results_tracking$R2_Put_Theo
  )
  
  # Add summary statistics
  summary_stats <- data.frame(
    Metric = c("Mean", "Min", "Max", "Std Dev"),
    RMSE_Call_Scambio = c(mean(results_df$RMSE_Call_Scambio), 
                          min(results_df$RMSE_Call_Scambio),
                          max(results_df$RMSE_Call_Scambio),
                          sd(results_df$RMSE_Call_Scambio)),
    RMSE_Put_Scambio = c(mean(results_df$RMSE_Put_Scambio),
                         min(results_df$RMSE_Put_Scambio),
                         max(results_df$RMSE_Put_Scambio),
                         sd(results_df$RMSE_Put_Scambio)),
    R2_Call_Scambio = c(mean(results_df$R2_Call_Scambio),
                        min(results_df$R2_Call_Scambio),
                        max(results_df$R2_Call_Scambio),
                        sd(results_df$R2_Call_Scambio)),
    R2_Put_Scambio = c(mean(results_df$R2_Put_Scambio),
                       min(results_df$R2_Put_Scambio),
                       max(results_df$R2_Put_Scambio),
                       sd(results_df$R2_Put_Scambio))
  )
  
  # Return all results
  list(
    best_results = best_results,
    results_df = results_df,
    summary_stats = summary_stats
  )
}

# Run the model selection
results_sigma2 <- run_model_selection(final_train_data)

# Access the comprehensive results dataframe
results_df_sigma2 <- results_sigma2$results_df

# Save both objects to a single .RData file
save(results_df_sigma2, results_sigma2, file = "XGBOOST_wrt_sigma2.RData")

# View summary statistics
print(results_sigma2$summary_stats)
print(results_sigma2$best_results)

# Plot RMSE improvement across feature subsets

ggplot(results_df_sigma2, aes(x = Feature_Set)) +
  geom_line(aes(y = RMSE_Call_Scambio, color = "Call Scambio")) +
  geom_line(aes(y = RMSE_Put_Scambio, color = "Put Scambio")) +
  labs(title = "RMSE Improvement Across Feature Subsets",
       y = "RMSE",
       color = "Model Type") +
  theme_minimal()


# Variable importance for Call (Exchange) model
importance_call_exchange <- 
  xgb.importance(model = results_sigma2$best_results$call_scambio$model)
xgb.plot.importance(importance_call_exchange, 
                    main = "Variable Importance (Call - Exchange)")

# Variable importance for Put (Exchange) model
importance_put_exchange <- 
  xgb.importance(model = results_sigma2$best_results$put_scambio$model)
xgb.plot.importance(importance_put_exchange,
                    main = "Variable Importance (Put - Exchange)")

# Variable importance for Call (Theoretical) model
importance_call_theoretical <- 
  xgb.importance(model = results_sigma2$best_results$call_theo$model)
xgb.plot.importance(importance_call_theoretical,
                    main = "Variable Importance (Call - Theoretical)")

# Variable importance for Put (Theoretical) model
importance_put_theoretical <- 
  xgb.importance(model = results_sigma2$best_results$put_theo$model)
xgb.plot.importance(importance_put_theoretical,
                    main = "Variable Importance (Put - Theoretical)")

# Density plot for Call options predictions (Exchange)
p_exchange_call_density <- ggplot(data.frame(
  Predictions = results_sigma2$best_results$call_scambio$predictions), 
  aes(x = Predictions)) +
  geom_density(fill = "blue", alpha = 0.3) +
  labs(title = "Prediction Density for Call Options (Exchange)",
       x = "Predicted Prices",
       y = "Density") +
  theme_minimal()
print(p_exchange_call_density)

# Density plot for Put options predictions (Exchange)
p_exchange_put_density <- ggplot(data.frame(
  Predictions = results_sigma2$best_results$put_scambio$predictions),
  aes(x = Predictions)) +
  geom_density(fill = "red", alpha = 0.3) +
  labs(title = "Prediction Density for Put Options (Exchange)",
       x = "Predicted Prices",
       y = "Density") +
  theme_minimal()
print(p_exchange_put_density)

# Density plot for Call options predictions (Theoretical)
p_theo_call_density <- ggplot(data.frame(
  Predictions = results_sigma2$best_results$call_theo$predictions),
  aes(x = Predictions)) +
  geom_density(fill = "blue", alpha = 0.3) +
  labs(title = "Prediction Density for Call Options (Theoretical)",
       x = "Predicted Prices",
       y = "Density") +
  theme_minimal()
print(p_theo_call_density)

# Density plot for Put options predictions (Theoretical)
p_theo_put_density <- ggplot(data.frame(
  Predictions = results_sigma2$best_results$put_theo$predictions), 
  aes(x = Predictions)) +
  geom_density(fill = "red", alpha = 0.3) +
  labs(title = "Prediction Density for Put Options (Theoretical)",
       x = "Predicted Prices",
       y = "Density") +
  theme_minimal()
print(p_theo_put_density)

# Scatter plot for Call options (Observed vs Predicted)
p_call <- ggplot(data = data.frame(
  Observed = results_sigma2$best_results$call_scambio$test_targets, 
  Predicted = results_sigma2$best_results$call_scambio$predictions), 
  aes(x = Observed, y = Predicted)) +
  geom_point(color = "blue", alpha = 0.6) +
  geom_abline(intercept = 0, slope = 1, color = "green", linetype = "dashed", size = 1) +
  labs(title = "Observed vs Predicted Values (Call Options)",
       x = "Observed Values",
       y = "Predicted Values") +
  theme_minimal()
print(p_call)

# Scatter plot for Put options (Observed vs Predicted)
p_put <- ggplot(data = data.frame(
  Observed = results_sigma2$best_results$put_scambio$test_targets, 
  Predicted = results_sigma2$best_results$put_scambio$predictions),
  aes(x = Observed, y = Predicted)) +
  geom_point(color = "red", alpha = 0.6) +
  geom_abline(intercept = 0, slope = 1, color = "green", linetype = "dashed", size = 1) +
  labs(title = "Observed vs Predicted Values (Put Options)",
       x = "Observed Values",
       y = "Predicted Values") +
  theme_minimal()
print(p_put)







