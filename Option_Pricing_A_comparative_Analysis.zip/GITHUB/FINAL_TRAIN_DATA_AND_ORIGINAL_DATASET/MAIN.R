# Load necessary libraries
library(tidyverse)
library(quantmod)
library(Rlof)

# Set the working directory and read the data
dati <- read.csv("C:/Users/Manli/Desktop/TESI/DATASET_E_DATI_ORIGINALI/flex_trades_eod_2024-06-20.csv", sep=";")


# Filter symbols and manipulate data
simboli <- unique(dati$underlying_symbol) %>% 
  str_subset(., pattern = "\\^", negate = TRUE)

dati_rid <- dati %>% 
  filter(underlying_symbol %in% simboli, exercise == "E") %>% 
  mutate(
    expiration = as.Date(expiration, format = "%d/%m/%Y"),
    trade_datetime = as.Date(trade_datetime),
    n_giorni = as.numeric(expiration - trade_datetime)
  )

# Define date ranges for volatility calculation
date_ranges <- list(
  c(as.Date("2023-06-20"), as.Date("2024-06-20")),
  c(as.Date("2022-06-20"), as.Date("2024-06-20")),
  c(as.Date("2021-06-20"), as.Date("2024-06-20"))
)

# Define function to calculate volatility
calcola_volatilita <- function(symbol, date_range) {
  tryCatch({
    getSymbols(symbol, src = "yahoo", from = date_range[1], to = date_range[2],
               auto.assign = FALSE) %>%
      Ad() %>% log() %>% diff() %>%
      sd(na.rm = TRUE) * sqrt(252)
  }, error = function(e) {
    return(NA)  # Return NA if the symbol or data isn't available
  })
}

# Apply volatility function to each symbol and date range
volatilita_list <- lapply(simboli, function(i) {
  sapply(date_ranges, function(range) calcola_volatilita(i, range),
         simplify = TRUE)
}) %>% set_names(simboli)

# Convert results to a dataframe
support <- bind_rows(lapply(names(volatilita_list), function(symbol) {
  # Ensure the volatility data is in the right format
  volatility_values <- volatilita_list[[symbol]]
  
  # Create a data frame for each symbol, handling the volatility list appropriately
  data.frame(
    simbolo = symbol,
    volatilita_annuale_1 = volatility_values[[1]],
    volatilita_annuale_2 = volatility_values[[2]],
    volatilita_annuale_3 = volatility_values[[3]]
  )
}))

# Merge volatility data with original dataset
dati_rid <- dati_rid %>% 
  left_join(support, by = c("underlying_symbol" = "simbolo"))

# Convert volatility columns to numeric
colonne_volatilita <- paste0("volatilita_annuale_", seq_along(date_ranges))
dati_rid <- dati_rid %>% mutate(across(all_of(colonne_volatilita), as.numeric))

# Save the dataset
save(dati_rid, file = "DATI_TESI.RData")

# Reload data and split into calls and puts
load("DATI_TESI.RData")
data_calls <- dati_rid %>% filter(option_type == 'c') %>% select(-option_type)
data_puts  <- dati_rid %>% filter(option_type == 'p') %>% select(-option_type)

# Apply LOF (Local Outlier Factor) to numeric columns of calls and puts
lof_apply <- function(data, k_neighbors) {
  data_numeric <- data %>% select(where(is.numeric))
  lof(data_numeric, k = k_neighbors)
}

k_neighbors <- 20  # Set neighbors for LOF
call_LOF <- lof_apply(data_calls, k_neighbors)
put_LOF  <- lof_apply(data_puts, k_neighbors)

# Set a threshold for outliers (e.g., 95th percentile)
threshold_call <- quantile(call_LOF, 0.95)
threshold_put <- quantile(put_LOF, 0.95)

# Separate inliers and outliers
inlier_outlier_sep <- function(LOF, dataset, threshold) {
  inliers <- LOF <= threshold
  list(
    inlier = dataset[inliers, ],
    outlier = dataset[!inliers, ]
  )
}

# Separate inliers and outliers for calls and puts
call_inlier_outlier <- inlier_outlier_sep(call_LOF, data_calls, threshold_call)
put_inlier_outlier <- inlier_outlier_sep(put_LOF, data_puts, threshold_put)

# Combine inliers and add the 'option_type' column back
call_inlier <- call_inlier_outlier$inlier %>% mutate(option_type = 'c')
put_inlier  <- put_inlier_outlier$inlier %>% mutate(option_type = 'p')

# Final dataset: combine inliers and shuffle rows
final_train_data <- bind_rows(call_inlier, put_inlier) %>%
  sample_frac(1, replace = FALSE)  # Shuffle rows

# Save final dataset
save(final_train_data, file = "DATASET_DEFINITIVO.RDATA")
