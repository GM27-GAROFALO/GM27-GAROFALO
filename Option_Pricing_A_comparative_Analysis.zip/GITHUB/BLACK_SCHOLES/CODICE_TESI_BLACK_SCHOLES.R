rm(list = ls())

library(dplyr)
library(rpart)
library(Metrics)
library(knitr)
library(kableExtra)
library(gridExtra)

# Set working directory and load data
setwd("C:/Users/Manli/Desktop/TESI")
load("C:/Users/Manli/Desktop/TESI/DATASET_DEFINITIVO.RDATA")
data <- final_train_data
data$option_type<-as.factor(data$option_type)
data$n_giorni <- as.numeric(data$n_giorni)

# Define Black-Scholes function
black_scholes <- function(S, X, T_days, sigma, r = 0.051, option_type) {
  T <- T_days / 252 # Conversion from calendar days to trading years 
  # Calculate d1 and d2
  d1 <- (log(S / X) + (r + 0.5 * sigma^2) * T) / (sigma * sqrt(T))
  d2 <- d1 - sigma * sqrt(T)
  
  # Calculate price based on option type  
  if (option_type == "c") {
    price <- S * pnorm(d1) - X * exp(-r * T) * pnorm(d2)
  } else if (option_type == "p") {
    price <- X * exp(-r * T) * pnorm(-d2) - S * pnorm(-d1)
  } else {
    stop("Invalid option type. Use 'c' for call or 'p' for put.")
  }
  
  return(price)
}

# Define volatility vectors
volatilities <- list(data$volatilita_annuale_1, data$volatilita_annuale_2, data$volatilita_annuale_3)

# Calculate Black-Scholes prices for each volatility
for (i in seq_along(volatilities)) {
  col_name <- paste0("bs_price_sigma", i)
  data[[col_name]] <- mapply(black_scholes,
                             S = data$underlying_trade_price,
                             X = data$strike,
                             T_days = data$n_giorni,
                             sigma = volatilities[[i]],
                             MoreArgs = list(r = 0.051),
                             option_type = data$option_type)
}



# Split data into Call and Put options
dati_call <- data %>% filter(option_type == "c")
dati_put <- data %>% filter(option_type == "p")

# Calculate RMSE for each volatility and option type
#CALL
rmse_sigma1_call <- rmse(dati_call$trade_price, dati_call$bs_price_sigma1)
rmse_sigma2_call <- rmse(dati_call$trade_price, dati_call$bs_price_sigma2)
rmse_sigma3_call <- rmse(dati_call$trade_price, dati_call$bs_price_sigma3)

#PUT
rmse_sigma1_put <- rmse(dati_put$trade_price, dati_put$bs_price_sigma1)
rmse_sigma2_put <- rmse(dati_put$trade_price, dati_put$bs_price_sigma2)
rmse_sigma3_put <- rmse(dati_put$trade_price, dati_put$bs_price_sigma3)


# Calculate RMSE with respect to theoretical prices
#CALL
rmse_th_sigma1_call <- rmse(dati_call$theo_price,dati_call$bs_price_sigma1)
rmse_th_sigma2_call <- rmse(dati_call$theo_price,dati_call$bs_price_sigma2)
rmse_th_sigma3_call <- rmse(dati_call$theo_price,dati_call$bs_price_sigma3)

#PUT
rmse_th_sigma1_put <- rmse(dati_put$theo_price,dati_put$bs_price_sigma1)
rmse_th_sigma2_put <- rmse(dati_put$theo_price,dati_put$bs_price_sigma2)
rmse_th_sigma3_put <- rmse(dati_put$theo_price,dati_put$bs_price_sigma3)

# Create RMSE table
rmse_table <- data.frame(
  Tipo = c("Call", "Call", "Call", "Put", "Put", "Put"),
  Sigma = c("Sigma 1", "Sigma 2", "Sigma 3", "Sigma 1", "Sigma 2", "Sigma 3"),
  RMSE_Trade_Price = c(rmse_sigma1_call, rmse_sigma2_call, rmse_sigma3_call,
                       rmse_sigma1_put, rmse_sigma2_put, rmse_sigma3_put),
  RMSE_Theo_Price = c(rmse_th_sigma1_call, rmse_th_sigma2_call, rmse_th_sigma3_call,
                      rmse_th_sigma1_put, rmse_th_sigma2_put, rmse_th_sigma3_put)
)


kable(rmse_table, format = "pipe", col.names = c("Tipo", "Sigma", "RMSE Trade Price", "RMSE Theo Price")) %>%
  kable_styling(full_width = FALSE, position = "center")

#Calculation of R^2 for Call options
# Sigma 1
rss_sigma1_call <- sum((dati_call$bs_price_sigma1 - dati_call$trade_price)^2)
tss_call <- sum((dati_call$trade_price - mean(dati_call$trade_price))^2)
r_squared_sigma1_call <- 1 - (rss_sigma1_call / tss_call)
print(paste("R^2 per Call con Sigma 1:", r_squared_sigma1_call))

# Sigma 2
rss_sigma2_call <- sum((dati_call$bs_price_sigma2 - dati_call$trade_price)^2)
tss_call <- sum((dati_call$trade_price - mean(dati_call$trade_price))^2)
r_squared_sigma2_call <- 1 - (rss_sigma2_call / tss_call)
print(paste("R^2 per Call con Sigma 2:", r_squared_sigma2_call))

#  Sigma 3
rss_sigma3_call <- sum((dati_call$bs_price_sigma3 - dati_call$trade_price)^2)
tss_call <- sum((dati_call$trade_price - mean(dati_call$trade_price))^2)
r_squared_sigma3_call <- 1 - (rss_sigma3_call / tss_call)
print(paste("R^2 per Call con Sigma 3:", r_squared_sigma3_call))

# Calculation of R^2 for PUT options 
# Sigma 1
rss_sigma1_put <- sum((dati_put$bs_price_sigma1 - dati_put$trade_price)^2)
tss_put <- sum((dati_put$trade_price - mean(dati_put$trade_price))^2)
r_squared_sigma1_put <- 1 - (rss_sigma1_put / tss_put)
print(paste("R^2 per Put con Sigma 1:", r_squared_sigma1_put))

# Sigma 2
rss_sigma2_put <- sum((dati_put$bs_price_sigma2 - dati_put$trade_price)^2)
tss_put <- sum((dati_put$trade_price - mean(dati_put$trade_price))^2)
r_squared_sigma2_put <- 1 - (rss_sigma2_put / tss_put)
print(paste("R^2 per Put con Sigma 2:", r_squared_sigma2_put))

# Sigma 3
rss_sigma3_put <- sum((dati_put$bs_price_sigma3 - dati_put$trade_price)^2)
tss_put <- sum((dati_put$trade_price - mean(dati_put$trade_price))^2)
r_squared_sigma3_put <- 1 - (rss_sigma3_put / tss_put)
print(paste("R^2 per Put con Sigma 3:", r_squared_sigma3_put))



# Scatter plots for Call options

# First scatter plot for Call (trade price vs BS price Sigma 1)
p1 <- ggplot(dati_call, aes(x = trade_price, y = bs_price_sigma1)) +
  geom_point(color = "blue") +
  geom_abline(intercept = 0, slope = 1, color = "green", linetype = "dashed") +
  labs(x = "Observed Trade Price", y = "BS Price Sigma 1") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16),  # Modify x-axis text size
    axis.text.y = element_text(size = 16),  # Modify y-axis text size
    axis.title.x = element_text(size = 18), # Modify x-axis title size
    axis.title.y = element_text(size = 18)  # Modify y-axis title size
  )

# Second scatter plot for Call (trade price vs BS price Sigma 2)
p2 <- ggplot(dati_call, aes(x = trade_price, y = bs_price_sigma2)) +
  geom_point(color = "blue") +
  geom_abline(intercept = 0, slope = 1, color = "green", linetype = "dashed") +
  labs(x = "Observed Trade Price", y = "BS Price Sigma 2") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16),  # Modify x-axis text size
    axis.text.y = element_text(size = 16),  # Modify y-axis text size
    axis.title.x = element_text(size = 18), # Modify x-axis title size
    axis.title.y = element_text(size = 18)  # Modify y-axis title size
  )

# Third scatter plot for Call (trade price vs BS price Sigma 3)
p3 <- ggplot(dati_call, aes(x = trade_price, y = bs_price_sigma3)) +
  geom_point(color = "blue") +
  geom_abline(intercept = 0, slope = 1, color = "green", linetype = "dashed") +
  labs(x = "Observed Trade Price", y = "BS Price Sigma 3") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16),  # Modify x-axis text size
    axis.text.y = element_text(size = 16),  # Modify y-axis text size
    axis.title.x = element_text(size = 18), # Modify x-axis title size
    axis.title.y = element_text(size = 18)  # Modify y-axis title size
  )

# Combine the three scatter plots into a single row
p_combined <- grid.arrange(p1, p2, p3, nrow = 1, ncol = 3)

# Save the combined plot for Call options
ggsave("confronto_call.png", plot = p_combined, width = 14, height = 5)

##### Density comparison for Call options

# Density plot comparing observed vs predicted prices for Call options
p5 <- ggplot() +
  geom_density(data = dati_call, aes(x = trade_price, color = "Observed"), size = 1) +
  geom_density(data = dati_call, aes(x = bs_price_sigma1, color = "Predicted (Sigma 1)"), linetype = "dashed", size = 1) +
  geom_density(data = dati_call, aes(x = bs_price_sigma2, color = "Predicted (Sigma 2)"), linetype = "dotted", size = 1) +
  geom_density(data = dati_call, aes(x = bs_price_sigma3, color = "Predicted (Sigma 3)"), linetype = "longdash", size = 1) +
  labs(x = "Price", y = "Density", color = "Legend") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16),  # Modify x-axis text size
    axis.text.y = element_text(size = 16),  # Modify y-axis text size
    axis.title.x = element_text(size = 18), # Modify x-axis title size
    axis.title.y = element_text(size = 18)  # Modify y-axis title size
  )

# Display the density plot
p5

# Save the density comparison plot for Call options
ggsave("confronto_call_1.png", plot = p5, width = 14, height = 5)

# Scatter plots for Put options

# First scatter plot for Put (trade price vs BS price Sigma 1)
p6 <- ggplot(dati_put, aes(x = trade_price, y = bs_price_sigma1)) +
  geom_point(color = "red") +
  geom_abline(intercept = 0, slope = 1, color = "green", linetype = "dashed") +
  labs(x = "Observed Trade Price", y = "BS Price Sigma 1") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16),  # Modify x-axis text size
    axis.text.y = element_text(size = 16),  # Modify y-axis text size
    axis.title.x = element_text(size = 18), # Modify x-axis title size
    axis.title.y = element_text(size = 18)  # Modify y-axis title size
  )

# Second scatter plot for Put (trade price vs BS price Sigma 2)
p7 <- ggplot(dati_put, aes(x = trade_price, y = bs_price_sigma2)) +
  geom_point(color = "red") +
  geom_abline(intercept = 0, slope = 1, color = "green", linetype = "dashed") +
  labs(x = "Observed Trade Price", y = "BS Price Sigma 2") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16),  # Modify x-axis text size
    axis.text.y = element_text(size = 16),  # Modify y-axis text size
    axis.title.x = element_text(size = 18), # Modify x-axis title size
    axis.title.y = element_text(size = 18)  # Modify y-axis title size
  )

# Third scatter plot for Put (trade price vs BS price Sigma 3)
p8 <- ggplot(dati_put, aes(x = trade_price, y = bs_price_sigma3)) +
  geom_point(color = "red") +
  geom_abline(intercept = 0, slope = 1, color = "green", linetype = "dashed") +
  labs(x = "Observed Trade Price", y = "BS Price Sigma 3") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16),  # Modify x-axis text size
    axis.text.y = element_text(size = 16),  # Modify y-axis text size
    axis.title.x = element_text(size = 18), # Modify x-axis title size
    axis.title.y = element_text(size = 18)  # Modify y-axis title size
  )

# Combine the three scatter plots for Put options into a single row
p_combined_1 <- grid.arrange(p6, p7, p8, nrow = 1, ncol = 3)

# Save the combined plot for Put options
ggsave("confronto_put.png", plot = p_combined_1, width = 14, height = 5)

#### Density comparison for Put options

# Density plot comparing observed vs predicted prices for Put options
p9 <- ggplot() +
  geom_density(data = dati_put, aes(x = trade_price, color = "Observed"), size = 1) +
  geom_density(data = dati_put, aes(x = bs_price_sigma1, color = "Predicted (Sigma 1)"), linetype = "dashed", size = 1) +
  geom_density(data = dati_put, aes(x = bs_price_sigma2, color = "Predicted (Sigma 2)"), linetype = "dotted", size = 1) +
  geom_density(data = dati_put, aes(x = bs_price_sigma3, color = "Predicted (Sigma 3)"), linetype = "longdash", size = 1) +
  labs(x = "Price", y = "Density", color = "Legend") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16),  # Modify x-axis text size
    axis.text.y = element_text(size = 16),  # Modify y-axis text size
    axis.title.x = element_text(size = 18), # Modify x-axis title size
    axis.title.y = element_text(size = 18)  # Modify y-axis title size
  )

# Display the density plot
p9

# Save the density comparison plot for Put options
ggsave("confronto_put_1.png", plot = p9, width = 14, height = 5)

############## Removal of observation 246
dati_put <- dati_put[-246,]  # Remove observation 246 from the dataset
View(dati_put)

# RMSE calculations for Put options
rmse_sigma1_put <- rmse(dati_put$trade_price, dati_put$bs_price_sigma1)
rmse_sigma2_put <- rmse(dati_put$trade_price, dati_put$bs_price_sigma2)
rmse_sigma3_put <- rmse(dati_put$trade_price, dati_put$bs_price_sigma3)

                        