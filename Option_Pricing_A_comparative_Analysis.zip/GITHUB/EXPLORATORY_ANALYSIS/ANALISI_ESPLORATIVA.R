library(ggplot2)
library(cowplot)
library(gridExtra)
library(reshape2)
library(dplyr)
library(tidyr)

rm(list = ls())
setwd("C:/Users/Manli/Desktop/magistrale/TESI_GAROFALO_GIOVANNI/DATASET_E_DATI_ORIGINALI")
load("DATASET_DEFINITIVO.RData")
dati_rid <- final_train_data
dati_rid$option_type <- as.factor(dati_rid$option_type)
dati_rid$n_giorni <- as.numeric(dati_rid$n_giorni)
attach(dati_rid)

# Find out how many options have a price equal to 0 and less than 1
num_osservazioni <- dati_rid %>% 
  filter(trade_price == 0) %>% 
  nrow()
print(num_osservazioni)

num_osservazioni <- dati_rid %>% 
  filter(trade_price < 1) %>% 
  nrow()
print(num_osservazioni)

# Data for Call and Put
dati_call <- dati_rid %>% filter(option_type == "c")
dati_put <- dati_rid %>% filter(option_type == "p")

# Summary statistics for Call and Put trade prices
summary(dati_call$trade_price)
summary(dati_put$trade_price)

# Number of Call and Put options with price less than 1
num_osservazioni <- dati_call %>% 
  filter(trade_price < 1) %>% 
  nrow()
print(num_osservazioni)

num_osservazioni <- dati_put %>% 
  filter(trade_price < 1) %>% 
  nrow()
print(num_osservazioni)

# Call trade price boxplot
grafico_call <- ggplot(dati_call, aes(x = "", y = trade_price)) +
  geom_boxplot(color = "blue", size = 1) +
  labs(title = "Call Option Trade Price", 
       y = "Call Price") +
  theme_minimal() +
  coord_cartesian(ylim = c(min(dati_call$trade_price), quantile(dati_call$trade_price, 0.95)))

# Put trade price boxplot
grafico_put <- ggplot(dati_put, aes(x = "", y = trade_price)) +
  geom_boxplot(color = "red", size = 1) +
  labs(title = "Put Option Trade Price", 
       y = "Put Price") +
  theme_minimal() +
  coord_cartesian(ylim = c(min(dati_put$trade_price), quantile(dati_put$trade_price, 0.95)))

print(grafico_call)
print(grafico_put)

##### Density Plots for Call and Put

density_call <- ggplot(dati_call, aes(x = trade_price)) +
  geom_density(fill = "lightblue", color = "blue", alpha = 0.7) +
  labs(x = "Trade Price", y = "Density") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16), 
    axis.text.y = element_text(size = 16),  
    axis.title.x = element_text(size = 18), 
    axis.title.y = element_text(size = 18)  
  )

density_put <- ggplot(dati_put, aes(x = trade_price)) +
  geom_density(fill = "lightcoral", color = "red", alpha = 0.7) +
  xlim(0, 100) +
  labs(x = "Trade Price", y = "Density") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16), 
    axis.text.y = element_text(size = 16),  
    axis.title.x = element_text(size = 18), 
    axis.title.y = element_text(size = 18)  
  )

# Display density plots
print(density_call)
print(density_put)

# Save the boxplots and density plots
ggsave("boxplot_call.png", plot = grafico_call, width = 10, height = 5)
ggsave("boxplot_put.png", plot = grafico_put, width = 10, height = 5)

ggsave("density_call.png", plot = density_call, width = 14, height = 5)
ggsave("density_put.png", plot = density_put, width = 14, height = 5)

##### Trade Price as a Function of Days to Maturity

grafico_maturità <- ggplot(dati_rid, aes(x = n_giorni, fill = option_type)) +
  geom_histogram(binwidth = 5, alpha = 0.7, position = "identity") +
  labs(x = "Number of Days", y = "Frequency") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16), 
    axis.text.y = element_text(size = 16), 
    axis.title.x = element_text(size = 18), 
    axis.title.y = element_text(size = 18)  
  ) +
  scale_fill_manual(values = c("blue", "red"), labels = c("Call", "Put"))

print(grafico_maturità)
ggsave("grafico_maturità.pdf", plot = grafico_maturità, width = 14, height = 5)

# Call option price vs days to maturity
grafico_call_1 <- ggplot(dati_call, aes(x = n_giorni, y = trade_price, color = option_type)) +
  geom_point() +
  labs(x = "Number of Days", y = "Call Trade Price") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16), 
    axis.text.y = element_text(size = 16), 
    axis.title.x = element_text(size = 18), 
    axis.title.y = element_text(size = 18)  
  ) +
  scale_color_manual(values = c("blue", "red"), labels = c("Call", "Put")) +
  coord_cartesian(xlim = c(min(dati_call$n_giorni), max(dati_call$n_giorni)), 
                  ylim = c(min(dati_call$trade_price), quantile(dati_call$trade_price, 0.95)))

# Put option price vs days to maturity
grafico_put_1 <- ggplot(dati_put, aes(x = n_giorni, y = trade_price, color = option_type)) +
  geom_point() +
  labs(x = "Number of Days", y = "Put Trade Price") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16), 
    axis.text.y = element_text(size = 16), 
    axis.title.x = element_text(size = 18), 
    axis.title.y = element_text(size = 18)  
  ) +
  scale_color_manual(values = "red", labels = "Put") +
  coord_cartesian(xlim = c(min(dati_put$n_giorni), max(dati_put$n_giorni)), 
                  ylim = c(min(dati_put$trade_price), quantile(dati_put$trade_price, 0.95)))

print(grafico_call_1)
print(grafico_put_1)

ggsave("prezzi_call_vs_maturita.pdf", plot = grafico_call_1, width = 14, height = 5)
ggsave("prezzi_put_vs_maturita.pdf", plot = grafico_put_1, width = 14, height = 5)

#####Trade price as a function of the underlying asset price#####

# Call Price Chart 
call_price_chart <- ggplot(dati_call, aes(x = underlying_trade_price, y = trade_price)) +
  geom_point(color = "blue") +
  labs( 
    x = "Underlying Asset Trade Price", y = "Call Price") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16),  # Modify the size of text on the x-axis
    axis.text.y = element_text(size = 16),  # Modify the size of text on the y-axis
    axis.title.x = element_text(size = 18), # Modify the size of the x-axis title
    axis.title.y = element_text(size = 18)  # Modify the size of the y-axis title
  ) +
  ylim(0, quantile(dati_call$trade_price, 0.95))


# Put Price Chart 
put_price_chart <- ggplot(dati_put, aes(x = underlying_trade_price, y = trade_price)) +
  geom_point(color = "red") +
  labs( 
    x = "Underlying Asset Trade Price", y = "Put Price") +
  ylim(0, quantile(dati_put$trade_price, 0.95)) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16),  # Modify the size of text on the x-axis
    axis.text.y = element_text(size = 16),  # Modify the size of text on the y-axis
    axis.title.x = element_text(size = 18), # Modify the size of the x-axis title
    axis.title.y = element_text(size = 18)  # Modify the size of the y-axis title
  )

# Display the charts
print(call_price_chart)
print(put_price_chart)

# Save the charts as images
ggsave("call_price_chart.png", plot = call_price_chart, width = 14, height = 5)
ggsave("put_price_chart.png", plot = put_price_chart, width = 14, height = 5)


#####Trade prices as a function of strike price K############

# Call Trade price as a function of strike price
call_strike_chart <- ggplot(dati_call, aes(x = strike, y = trade_price)) +
  geom_point(color = "blue") +
  labs( 
    x = "Strike Price", y = "Call Price") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16),  # Modify the size of text on the x-axis
    axis.text.y = element_text(size = 16),  # Modify the size of text on the y-axis
    axis.title.x = element_text(size = 18), # Modify the size of the x-axis title
    axis.title.y = element_text(size = 18)  # Modify the size of the y-axis title
  ) +
  coord_cartesian(xlim = c(min(strike), quantile(strike, 0.95)), 
                  ylim = c(min(trade_price), quantile(trade_price, 0.95)))

# Put Trade prices as a function of strike price
put_strike_chart <- ggplot(dati_put, aes(x = strike, y = trade_price)) +
  geom_point(color = "red") +
  labs(
    x = "Strike Price", y = "Put Price") +
  coord_cartesian(xlim = c(min(strike), quantile(strike, 0.95)), 
                  ylim = c(min(trade_price), quantile(trade_price, 0.85))) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16),  # Modify the size of text on the x-axis
    axis.text.y = element_text(size = 16),  # Modify the size of text on the y-axis
    axis.title.x = element_text(size = 18), # Modify the size of the x-axis title
    axis.title.y = element_text(size = 18)  # Modify the size of the y-axis title
  )

# Display the charts
print(call_strike_chart)
print(put_strike_chart)

# Save the charts as images
ggsave("call_strike_chart.png", plot = call_strike_chart, width = 14, height = 5)
ggsave("put_strike_chart.png", plot = put_strike_chart, width = 14, height = 5)


######### Call and Put Trade Prices vs Underlaying Historical Volatility #########

# Call option price vs Volatility (sigma 1)
grafico_call_vol1 <- ggplot(dati_call, aes(x = volatilita_annuale_1, y = trade_price)) +
  geom_point(color = "blue") +
  labs(x = "Annual Volatility 1", y = "Call Trade Price") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16), 
    axis.text.y = element_text(size = 16), 
    axis.title.x = element_text(size = 18), 
    axis.title.y = element_text(size = 18)  
  ) +
  ylim(0, quantile(dati_call$trade_price, 0.95))

grafico_call_vol2 <- ggplot(dati_call, aes(x = volatilita_annuale_2, y = trade_price)) +
  geom_point(color = "blue") +
  labs(x = "Annual Volatility 2", y = "Call Trade Price") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16), 
    axis.text.y = element_text(size = 16), 
    axis.title.x = element_text(size = 18), 
    axis.title.y = element_text(size = 18)  
  ) +
  ylim(0, quantile(dati_call$trade_price, 0.95))

grafico_call_vol3 <- ggplot(dati_call, aes(x = volatilita_annuale_3, y = trade_price)) +
  geom_point(color = "blue") +
  labs(x = "Annual Volatility 3", y = "Call Trade Price") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16), 
    axis.text.y = element_text(size = 16), 
    axis.title.x = element_text(size = 18), 
    axis.title.y = element_text(size = 18)  
  ) +
  ylim(0, quantile(dati_call$trade_price, 0.95))

# Put option price vs Volatility (Volatility 1)
grafico_put_vol1 <- ggplot(dati_put, aes(x = volatilita_annuale_1, y = trade_price)) +
  geom_point(color = "red") +
  labs(x = "Annual Volatility 1", y ="Put Trade Price") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16), 
    axis.text.y = element_text(size = 16), 
    axis.title.x = element_text(size = 18), 
    axis.title.y = element_text(size = 18)  
  ) +
  ylim(0, quantile(dati_put$trade_price, 0.95))

# Put option price vs Volatility (Volatility 2)
grafico_put_vol2 <- ggplot(dati_put, aes(x = volatilita_annuale_2, y = trade_price)) +
  geom_point(color = "red") +
  labs(x = "Annual Volatility 2", y = "Put Trade Price") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16), 
    axis.text.y = element_text(size = 16), 
    axis.title.x = element_text(size = 18), 
    axis.title.y = element_text(size = 18)  
  ) +
  ylim(0, quantile(dati_put$trade_price, 0.95))

# Put option price vs Volatility (Volatility 3)
grafico_put_vol3 <- ggplot(dati_put, aes(x = volatilita_annuale_3, y = trade_price)) +
  geom_point(color = "red") +
  labs(x = "Annual Volatility 3", y = "Put Trade Price") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16), 
    axis.text.y = element_text(size = 16), 
    axis.title.x = element_text(size = 18), 
    axis.title.y = element_text(size = 18)  
  ) +
  ylim(0, quantile(dati_put$trade_price, 0.95))

# Display Call and Put vs Volatility plots
print(grafico_call_vol1)
print(grafico_call_vol2)
print(grafico_call_vol3)

print(grafico_put_vol1)
print(grafico_put_vol2)
print(grafico_put_vol3)

# Save the plots
ggsave("call_vs_vol1.pdf", plot = grafico_call_vol1, width = 14, height = 5)
ggsave("call_vs_vol2.pdf", plot = grafico_call_vol2, width = 14, height = 5)
ggsave("call_vs_vol3.pdf", plot = grafico_call_vol3, width = 14, height = 5)

ggsave("put_vs_vol1.pdf", plot = grafico_put_vol1, width = 14, height = 5)
ggsave("put_vs_vol2.pdf", plot = grafico_put_vol2, width = 14, height = 5)
ggsave("put_vs_vol3.pdf", plot = grafico_put_vol3, width = 14, height = 5)


# sample of selected Underlying symbol

data_long <- melt(dati_rid[1:15,], id.vars = "underlying_symbol", 
                  measure.vars = c("volatilita_annuale_1", "volatilita_annuale_2", "volatilita_annuale_3"),
                  variable.name = "volatilita", value.name = "valore")

volatilità_annuale_plot1<-ggplot(data_long, aes(x = underlying_symbol, y = valore, fill = volatilita)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs( x = "Simbolo", y = "Valore della Volatilità Annuale") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16),  # Modifica la dimensione del testo sull'asse x
    axis.text.y = element_text(size = 16),  # Modifica la dimensione del testo sull'asse y
    axis.title.x = element_text(size = 18), # Modifica la dimensione del titolo dell'asse x
    axis.title.y = element_text(size = 18)  # Modifica la dimensione del titolo dell'asse y
  )+
  scale_fill_manual(values = c("blue", "yellow", "red"))
print(volatilità_annuale_plot1)
ggsave("volatilità_annuale_plot1.png", plot = volatilità_annuale_plot1, width = 14, height = 5)

#Underlying Annual Volatility as a Function of Days to Maturity
#Call

dati_long <- pivot_longer(dati_call, cols = c("volatilita_annuale_1", "volatilita_annuale_2", "volatilita_annuale_3"), names_to = "tipo_volatilita", values_to = "valore_volatilita")

volatilità_annuale_plot2_call<-ggplot(dati_long, aes(x = n_giorni, y = valore_volatilita, color = tipo_volatilita)) +
  geom_smooth(size = 1) +
  labs(
    x = "Numero di giorni", y = "Volatilità annuale") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16),  # Modifica la dimensione del testo sull'asse x
    axis.text.y = element_text(size = 16),  # Modifica la dimensione del testo sull'asse y
    axis.title.x = element_text(size = 18), # Modifica la dimensione del titolo dell'asse x
    axis.title.y = element_text(size = 18)  # Modifica la dimensione del titolo dell'asse y
  )+
  scale_color_manual(values = c("blue", "yellow", "red")) +
  theme(legend.title = element_blank())
print(volatilità_annuale_plot2_call)
ggsave("volatilità_annuale_plot2_call.png", plot = volatilità_annuale_plot2_call, width = 14, height = 5)

#Put
dati_long <- pivot_longer(dati_put, cols = c("volatilita_annuale_1", "volatilita_annuale_2", "volatilita_annuale_3"), names_to = "tipo_volatilita", values_to = "valore_volatilita")

volatilità_annuale_plot2_put<-ggplot(dati_long, aes(x = n_giorni, y = valore_volatilita, color = tipo_volatilita)) +
  geom_smooth(size = 1) +
  labs(
    x = "Numero di giorni", y = "Volatilità annuale") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 16),  # Modifica la dimensione del testo sull'asse x
    axis.text.y = element_text(size = 16),  # Modifica la dimensione del testo sull'asse y
    axis.title.x = element_text(size = 18), # Modifica la dimensione del titolo dell'asse x
    axis.title.y = element_text(size = 18)  # Modifica la dimensione del titolo dell'asse y
  )+
  scale_color_manual(values = c("blue", "yellow", "red")) +
  theme(legend.title = element_blank())
print(volatilità_annuale_plot2_put)
ggsave("volatilità_annuale_plot2_put.png", plot = volatilità_annuale_plot2_put, width = 14, height = 5)

######THEORETICAL IMPLIED VOLATILITY#####

#theoretical implied volatility density for call options
grafico_density_call <- ggplot(dati_call, aes(x = theo_iv)) +
  geom_density(fill = "lightblue", color = "blue", alpha = 0.7) +
  labs(title = "Distribuzione della Volatilità Implicita Teorica per le Opzioni Call", 
       x = "Volatilità Implicita Teorica", y = "Densità") +
  theme_minimal() +
  xlim(c(min(dati_call$theo_iv), quantile(dati_call$theo_iv, 0.95)))

#theoretical implied volatility density for put optionst
grafico_density_put <- ggplot(dati_put, aes(x = theo_iv)) +
  geom_density(fill = "lightcoral", color = "red", alpha = 0.7) +
  labs(title = "Distribuzione della Volatilità Implicita Teorica per le Opzioni Put", 
       x = "Volatilità Implicita Teorica", y = "Densità") +
  theme_minimal() +
  xlim(c(min(dati_put$theo_iv), quantile(dati_put$theo_iv, 0.95)))

# print graphs
print(grafico_density_call)
print(grafico_density_put)

###call
grafico_call_iv <- ggplot(dati_call, aes(x = n_giorni, y = theo_iv)) +
  geom_point(color = "blue", size = 1) +
  geom_smooth(method = "loess", se = FALSE,color="blue") +
  labs( 
    x = "Numero di giorni", y = "Volatilità Implicita") +
  theme_minimal()+
  theme(
    axis.text.x = element_text(size = 16),  # Modifica la dimensione del testo sull'asse x
    axis.text.y = element_text(size = 16),  # Modifica la dimensione del testo sull'asse y
    axis.title.x = element_text(size = 18), # Modifica la dimensione del titolo dell'asse x
    axis.title.y = element_text(size = 18)  # Modifica la dimensione del titolo dell'asse y
  )+
  coord_cartesian(ylim = c(min(dati_put$theo_iv), quantile(dati_put$theo_iv, 0.95)))

#Put
grafico_put_iv <- ggplot(dati_put, aes(x = n_giorni, y = theo_iv)) +
  geom_point(color = "red", size = 1) +
  geom_smooth(method = "loess", se = FALSE,color="red") +
  labs(
    x = "Numero di giorni", y = "Volatilità Implicita") +
  theme_minimal()+
  theme(
    axis.text.x = element_text(size = 16),  # Modifica la dimensione del testo sull'asse x
    axis.text.y = element_text(size = 16),  # Modifica la dimensione del testo sull'asse y
    axis.title.x = element_text(size = 18), # Modifica la dimensione del titolo dell'asse x
    axis.title.y = element_text(size = 18)  # Modifica la dimensione del titolo dell'asse y
  )+
  coord_cartesian(ylim = c(min(dati_put$theo_iv), quantile(dati_put$theo_iv, 0.95)))

print(grafico_call_iv)
print(grafico_put_iv)

ggsave("grafico_call_iv.png", plot = grafico_call_iv, width = 14, height = 5)
ggsave("grafico_put_iv.png", plot = grafico_put_iv, width = 14, height = 5)


###########THEORETICAL IMPLIED VOLATILITY WITH RESPECT TO STRIKE PRICE############

#CALL
grafico_call_iv_2 <- ggplot(dati_call, aes(x = theo_iv, y = trade_price)) +
  geom_point(color = "blue") +
  labs( 
    x = "Volatilità implicita", y = "Prezzo Call") +
  theme_minimal()+
  theme(
    axis.text.x = element_text(size = 16),  # Modifica la dimensione del testo sull'asse x
    axis.text.y = element_text(size = 16),  # Modifica la dimensione del testo sull'asse y
    axis.title.x = element_text(size = 18), # Modifica la dimensione del titolo dell'asse x
    axis.title.y = element_text(size = 18)  # Modifica la dimensione del titolo dell'asse y
  )+
  coord_cartesian(xlim = c(min(theo_iv), quantile(theo_iv,0.95)), 
                  ylim = c(min(trade_price), quantile(trade_price, 0.95)))


#PUT
grafico_put_iv_2 <- ggplot(dati_put, aes(x = theo_iv, y = trade_price)) +
  geom_point(color = "red") +
  labs( 
    x = "Volatilità implicita", y = "Prezzo Put") +
  coord_cartesian(xlim = c(min(theo_iv), quantile(theo_iv,0.95)), 
                  ylim = c(min(trade_price), quantile(trade_price, 0.85)))+
  theme_minimal()+
  theme(
    axis.text.x = element_text(size = 16),  # Modifica la dimensione del testo sull'asse x
    axis.text.y = element_text(size = 16),  # Modifica la dimensione del testo sull'asse y
    axis.title.x = element_text(size = 18), # Modifica la dimensione del titolo dell'asse x
    axis.title.y = element_text(size = 18)  # Modifica la dimensione del titolo dell'asse y
  )

print(grafico_call_iv_2)
print(grafico_put_iv_2)

ggsave("grafico_call_iv_2.png", plot = grafico_call_iv_2, width = 14, height = 5)
ggsave("grafico_put_iv_2.png", plot = grafico_put_iv_2, width = 14, height = 5)



