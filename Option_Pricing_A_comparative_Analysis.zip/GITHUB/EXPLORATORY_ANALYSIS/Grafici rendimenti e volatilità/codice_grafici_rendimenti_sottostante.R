library(quantmod)
library(dplyr)
library(ggplot2)
library(cowplot)
library(gridExtra)
library(reshape2)

load("DATI_TESI.RData")

# Calcola la volatilità storica annuale e i rendimenti giornalieri per ciascun simbolo
support <- lapply(simboli, FUN = function(i){
  getSymbols(i, src = "yahoo", from = data_inizio_serie, to = data_fine_serie, auto.assign = TRUE)
  prezzi <- get(i) %>%
    as_tibble() %>% 
    mutate(data_serie = index(get(i))) %>% 
    filter(between(data_serie, data_inizio_serie, data_fine_serie)) %>% 
    pull(contains("Adjusted"))
  
  # Calcola i rendimenti giornalieri
  rendimenti <- diff(log(prezzi))
  
  # Calcola la deviazione standard dei rendimenti giornalieri
  volatilita_giornaliera <- sd(rendimenti, na.rm = TRUE)
  
  # Scala la deviazione standard per ottenere la volatilità annuale
  volatilita_annuale <- volatilita_giornaliera * sqrt(252)
  
  
  dati <- data.frame(data_serie = index(get(i))[-1], rendimenti = rendimenti, 
                     volatilita_annuale = volatilita_annuale)
  
  if (nrow(dati) == 0 || any(is.na(dati$rendimenti))) {
    cat("Attenzione: dati vuoti o NAs per il simbolo:", i, "\n")
    return(NULL)
  }
  
#########grafico rendimentisottostante e volatilità storica
    grafico <- ggplot(dati, aes(x = data_serie, y = rendimenti)) +
    geom_line() +
    annotate("text", x = max(dati$data_serie, na.rm = TRUE), y = max(dati$rendimenti, na.rm = TRUE), 
             label = paste("Volatilità Annuale:", round(volatilita_annuale, 4)), 
             hjust = 1, vjust = 1, color = "red", size = 4) +
    labs(title = paste("Rendimenti per", i),
         x = "Data",
         y = "Rendimenti") +
    theme_minimal()
  
  return(grafico)
}) %>% 
  set_names(., nm = simboli)

# Rimuovi eventuali NULL nella lista
support <- Filter(Negate(is.null), support)

# Esporta i grafici in blocchi da 3x3 su più immagini
num_grafici <- length(support)
num_per_pagina <- 9
num_pagine <- ceiling(num_grafici / num_per_pagina)

for (pagina in 1:num_pagine) {
  start_idx <- (pagina - 1) * num_per_pagina + 1
  end_idx <- min(pagina * num_per_pagina, num_grafici)
  plot_list <- support[start_idx:end_idx]
  
  png(paste0("grafici_3x3_pagina_", pagina, ".png"), width = 1400, height = 1000)
  
  # Usa grid.arrange se plot_grid non funziona
  grid.arrange(grobs = plot_list, ncol = 3, nrow = 3)
  
  dev.off()
}
